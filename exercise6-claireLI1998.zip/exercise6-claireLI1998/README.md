CPEN 221 | Cutting and Splicing DNA
===

**But this is really about debugging.**

The complete details for this exercise can be found [on Notion](https://www.notion.so/cpen221ubc/Exercise-6-Cutting-and-Splicing-DNA-34902159c21640f0a428fc1bc8b87c3c).
